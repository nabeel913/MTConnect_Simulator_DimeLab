import socket
import time
import random
HOST = '127.0.0.1'
PORT = 14707

import pymongo
myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["mtconnectdatabase"]
mycol = mydb["orders"]
M="15Mach7"
myquery = { "_id": M }


while True:
    mydoc = mycol.find(myquery)
    for x in mydoc:
      order= ((x['Order']))
      QTY=((x['QTY']))
      PartID=((x['PartID']))
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        data=random.randint(50,95)
        breakdown=random.paretovariate(1)
        bd=0
        c=0
        if isinstance(order,str):
            ran = "Mach7|OEE|"+"UNAVAILABLE"+"|power|UNAVAILABLE"+"|Idle|Empty|UNAVAILABLE"
        if isinstance(order,int):    
            if('OFF'=='OFF'):
                data=0
            if('OFF'!='OFF') and (breakdown>=2) and (breakdown<=500):
                ran = "Mach7|OEE|"+str(data)+"|power|Cutting|"+str(order)+"|"+str(QTY)+"|"+PartID
                c=1
            if(c==0):
                ran = "Mach7|OEE|"+str(data)+"|power|OFF|"+str(order)+"|"+str(QTY)+"|"+PartID
       
        if breakdown>500:  
            ran = "Mach7|OEE|"+"UNAVAILABLE"+"|power|BREAKDOWN|"+str(order)+"|"+str(QTY)+"|"+PartID
            bd=1
                  
        time.sleep(1)
        strin=bytes(ran,encoding='utf-8')
        s.sendall(strin)
        if(bd==1):
           repairTime=random.randint(50,100)
           while repairTime>=1:
               time.sleep(1)
               repairTime-=1
           bd=0

