from flask import Flask,Response
import xml.etree.ElementTree as ET 
import datetime
from flask import render_template,request
import pandas as pd

def header_update(file):
    utcnow = datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
    tree = ET.parse(file) 
    root = tree.getroot()
    for elems in root.iter('Header'):
        elems.set('creationTime',str(utcnow))
        j= elems.get('instanceId')
        elems.set('instanceId',str(int(j)+1))
    tree.write(file)
    tree = ET.parse(file) 
    root2 = tree.getroot()
    return root2


def stream(file):
    tree = ET.parse(file) 
    root2 = tree.getroot()
    return root2


def sample(F=0,C=100):
    if F==0:
        buffer=pd.read_csv("buffer.txt",sep='|',names = ["Seq","time", "Mach", "na", "OEE","na2","power","order","qty","partid"])
    if F!=0:
        buffer=pd.read_csv("buffer.txt",sep='|',names = ["Seq","time", "Mach", "na", "OEE","na2","power","order","qty","partid"])
        buffer = buffer = buffer[(buffer.Seq>=int(F))&(buffer.Seq<=int(F)+int(C))]
    buffer=buffer.sort_values(by=['Mach'])
    root = ET.Element("MTConnectStreams")
    doc = ET.SubElement(root, "Streams")
    machs=(buffer.Mach.unique())
    for i in machs:
        xmlpd=(buffer[buffer.Mach==i])
        OEE=list(xmlpd['OEE'])
        seq=list(xmlpd['Seq'])
        time=list(xmlpd['time'])
        for O in range(len(OEE)):
            DS=ET.SubElement(doc, "DeviceStream",timestamp=time[O],sequence=str(seq[O]), name=i).text=str(OEE[O])
            
  
    tree = ET.ElementTree(root)
    tree.write("sample.xml")
    tree = ET.parse("sample.xml") 
    root3 = tree.getroot()
    return root3

app = Flask(__name__)

class MyResponse(Response):
    default_mimetype = 'application/xml'

@app.route('/<path:path>')
def get_sample(path):
    if path=="probe":
        return (ET.tostring(header_update('devices.xml'), encoding='UTF-8').decode('UTF-8'),{'Content-Type': 'application/xml'})
    if path=="current":
        return (ET.tostring(stream('streams.xml'), encoding='UTF-8').decode('UTF-8'),{'Content-Type': 'application/xml'})
    if path=="sample":
        if request.args.get('from')!=None:
            F=int(request.args.get('from'))
            if request.args.get('count')==None:
                C=100
            if request.args.get('count')!=None:
                C=int(request.args.get('count'))
 
            return (ET.tostring(sample(F,C), encoding='UTF-8').decode('UTF-8'),{'Content-Type': 'application/xml'})
        return (ET.tostring(sample(), encoding='UTF-8').decode('UTF-8'),{'Content-Type': 'application/xml'})

if __name__ == "__main__":
        app.run(host='0.0.0.0',port=15900 , threaded=True)