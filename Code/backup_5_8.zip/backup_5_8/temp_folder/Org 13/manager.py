
import xml.etree.ElementTree as ET 

import asyncio
import datetime
import time
ports=[10801, 10802, 10803, 10804, 10805, 10806, 10807]
file='streams.xml'


try:
    f=open("buffer.txt","r")
    b=f.readlines() 
    if len(b)>0:
        e=b[-1].split('|')
        seq=int(e[0])
except:
    seq=1

@asyncio.coroutine
async def handle_hello(reader, writer):
    global seq
    utcnow= datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
    f=open('buffer.txt','a+')
    data = await reader.read(1024)
    SHDR = data.decode('utf-8')
    f.write(str(seq)+"|"+str(utcnow)+"|"+SHDR+"\n")
    seq=seq+1

    data=(SHDR).split('|')
    m=str(data[0])
    o=str(data[5])
    p=str(data[7])
    q=str(data[6])
    for node in tree.findall("./Streams/DeviceStream[@name='%s']"%m):
        node.set('Order',o)
        node.set('PartID',p)
        node.set('QTY',q)
        utcnow= datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
        
        for a in node.findall('./Events/Power'):
            a.set('timestamp',utcnow)
            a.text=str(data[4])
        tree.write(file)  
        for b in node.findall('./Samples/OEE'):
            b.set('timestamp',utcnow)
            b.text=str(data[2])
    writer.write("Pong".encode("utf-8"))
    writer.close()
    f.seek(0)
    a=f.readlines()
    if(len(a)>1000):
        with open('buffer.txt', 'r') as fin:
            data = fin.read().splitlines(True)
        with open('buffer.txt', 'w') as fout:
            fout.writelines(data[500:])
  
if __name__ == "__main__":

    loop = asyncio.get_event_loop()
    servers = []
    for i in ports:
        #print("Starting server ",i)
        tree = ET.parse(file)
        server = loop.run_until_complete(
                asyncio.start_server(handle_hello, '127.0.0.1', i, loop=loop))   
        tree.write(file)
        
        servers.append(server)
    
    try:
        #print("Running... Press ^C to shutdown")
        #run loops of servers
        loop.run_forever()
    except KeyboardInterrupt:
        pass

    for i, server in enumerate(servers):
        #print("Closing server ",i)
        #if key pressed close all servers.
        server.close()
        loop.run_until_complete(server.wait_closed())
    loop.close()       
        